# FUNLISH - Aplikasi Pembelajaran Bahasa Inggris untuk SD

## 📚 Deskripsi
FUNLISH adalah aplikasi pembelajaran Bahasa Inggris berbasis web yang dirancang khusus untuk siswa SD kelas 3-6. Aplikasi ini menggunakan metode interaktif dan menyenangkan seperti Duolingo.

---

## ✨ Fitur Utama

### 1. **Sistem Kelas**
- **Kelas 3**: Materi dasar (warna, angka, buah, salam)
- **Kelas 4**: Aktivitas sehari-hari dan hewan
- **Kelas 5**: Grammar dasar dan percakapan
- **Kelas 6**: Reading dan vocabulary lanjutan

### 2. **Vocabulary (Kosakata)**
- Flashcard interaktif dengan sistem flip
- Gambar untuk setiap kosakata
- Audio pelafalan (Text-to-Speech atau file audio)
- Progress tracking
- Arti dalam Bahasa Indonesia

**Cara Kerja:**
1. Siswa melihat gambar dan kata Bahasa Inggris
2. Klik kartu untuk melihat arti Indonesia
3. Klik tombol audio untuk mendengar pelafalan
4. Navigasi antar kartu dengan tombol Previous/Next

### 3. **Listening (Mendengarkan)**
- Audio player interaktif
- Transkrip yang bisa ditampilkan/disembunyikan
- Progress tracking
- Audio berkualitas dengan kontrol play/pause

**Cara Kerja:**
1. Siswa mendengarkan audio dengan klik tombol play
2. Bisa mengulangi audio berkali-kali
3. Bisa melihat transkrip untuk bantuan
4. Lanjut ke audio berikutnya

### 4. **Quiz (Kuis Interaktif)**
Quiz terdiri dari **3 Level** dengan **5 Jenis Soal**:

#### a. **Vocabulary Matching**
- Mencocokkan kosakata dengan arti
- Multiple choice dengan 4 opsi
- Feedback langsung benar/salah
- Menampilkan jawaban yang benar jika salah

#### b. **Reading Comprehension**
- Membaca teks atau kalimat
- Menjawab pertanyaan berdasarkan bacaan
- Multiple choice
- Pembahasan lengkap

#### c. **Listening Comprehension**
- Mendengarkan audio
- Menjawab pertanyaan berdasarkan audio
- Audio bisa diputar ulang
- Feedback otomatis

#### d. **Speaking Assessment**
- Menggunakan **Web Speech API**
- Siswa mengucapkan kata yang diminta
- Sistem mendeteksi dan menilai pelafalan
- Real-time recognition
- Feedback pelafalan

#### e. **Memorizing via Image**
- Menampilkan gambar
- Siswa mengetik kosakata yang sesuai
- Case-insensitive checking
- Feedback dengan jawaban yang benar

**Sistem Quiz:**
- ✅ Tidak ada sistem unlock (semua level langsung terbuka)
- ✅ Feedback langsung saat salah
- ✅ Progress bar real-time
- ✅ Tidak ada sistem ranking
- ✅ Fokus pada pembelajaran, bukan kompetisi

---

## 🎨 Teknologi yang Digunakan

### Frontend
- **HTML5**: Struktur halaman
- **CSS3**: Styling dengan animasi modern
- **JavaScript (Vanilla)**: Interaktivitas dan logika
- **Font**: Fredoka (Google Fonts) - friendly dan child-appropriate
- **Icons**: Font Awesome 6

### Backend
- **PHP**: Server-side logic
- **MySQL**: Database management
- **PDO**: Database connection dengan prepared statements

### API & Fitur Modern
- **Web Speech API**: Speech Recognition untuk speaking assessment
- **SpeechSynthesis API**: Text-to-Speech untuk pronunciation
- **Fetch API**: Asynchronous data loading
- **LocalStorage/SessionStorage**: Session management

---

## 📁 Struktur File

```
SISMUL/
├── index.html              # Landing page
├── class-dashboard.html    # Dashboard kelas
├── vocabulary.html         # Halaman vocabulary
├── listening.html          # Halaman listening
├── quiz.html              # Halaman pilih quiz
├── quiz-play.html         # Halaman bermain quiz
├── style.css              # Main stylesheet
├── script.js              # Main JavaScript
├── config.php             # Database configuration
│
├── api/                   # API Endpoints
│   ├── get_kelas.php
│   ├── get_materi.php
│   ├── get_vocabulary.php
│   ├── get_listening.php
│   ├── get_quiz.php
│   ├── get_soal.php
│   └── admin/
│       ├── count_vocabulary.php
│       ├── count_quiz.php
│       └── count_soal.php
│
├── admin/                 # Admin Panel
│   ├── index.php
│   ├── login.php
│   └── logout.php
│
├── assets/               # Media files
│   ├── images/          # Gambar untuk vocabulary & soal
│   └── audio/           # File audio
│
├── db_funlish.sql        # Database schema
└── insert_sample_data.sql # Sample data
```

---

## 🚀 Cara Instalasi

### 1. **Setup Database**

```sql
-- Buat database
CREATE DATABASE db_funlish;

-- Import schema
SOURCE db_funlish.sql;

-- Import sample data
SOURCE insert_sample_data.sql;
```

### 2. **Konfigurasi**

Edit file `config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_funlish');
```

### 3. **Upload File Media**

Upload gambar ke folder:
- `assets/images/` - untuk gambar vocabulary dan soal
- `assets/audio/` - untuk file audio

### 4. **Login Admin**

Default credentials:
- Username: `admin`
- Password: `admin123`

URL Admin: `http://localhost/SISMUL/admin/login.php`

---

## 👨‍💻 Cara Menggunakan

### Untuk Siswa:

1. **Pilih Kelas**
   - Buka halaman utama
   - Klik "Masuk Kelas" sesuai kelas kamu
   
2. **Vocabulary**
   - Klik menu "Vocabulary"
   - Lihat gambar dan kata
   - Klik kartu untuk melihat arti
   - Klik audio untuk mendengar pelafalan
   
3. **Listening**
   - Klik menu "Listening"
   - Play audio dengan tombol play
   - Baca transkrip jika perlu
   
4. **Quiz**
   - Klik menu "Quiz"
   - Pilih level (1, 2, atau 3)
   - Pilih quiz yang ingin dikerjakan
   - Jawab soal sesuai tipe
   - Lihat feedback langsung

### Untuk Admin:

1. **Login ke Admin Panel**
   - Akses `/admin/login.php`
   - Masukkan username dan password
   
2. **Kelola Konten**
   - Dashboard: Lihat statistik
   - Materi: Tambah/edit materi pembelajaran
   - Vocabulary: Tambah/edit kosakata
   - Listening: Tambah/edit audio
   - Quiz: Tambah/edit quiz dan soal

---

## 🎯 Fitur Khusus

### 1. **Speech Recognition (Speaking Assessment)**
- Menggunakan browser's Speech Recognition API
- Support bahasa Inggris (en-US)
- Real-time transcription
- Similarity checking

**Browser Support:**
- ✅ Google Chrome
- ✅ Microsoft Edge
- ❌ Firefox (tidak support Web Speech API)
- ❌ Safari (terbatas)

### 2. **Text-to-Speech (Audio Pronunciation)**
- Fallback otomatis jika file audio tidak ada
- Menggunakan SpeechSynthesis API
- Pelafalan natural dengan rate control

### 3. **Progressive Learning**
- Semua level langsung bisa diakses
- Tidak ada lock system
- Fokus pada eksplorasi dan pembelajaran

---

## 🎨 Design System

### Color Palette:
- **Primary**: `#58cc02` (Green - Success/Learning)
- **Secondary**: `#667eea` (Purple - Quiz)
- **Warning**: `#ff9500` (Orange - Listening)
- **Danger**: `#e91e63` (Pink - Speaking)
- **Background**: `#f7fff5` (Light Green)

### Typography:
- **Font Family**: Fredoka (Google Fonts)
- **Headings**: 700 weight
- **Body**: 400-500 weight

### Components:
- Rounded corners (15-30px)
- Soft shadows
- Smooth transitions (0.3s)
- Hover effects
- Responsive design

---

## 📱 Responsive Design

Aplikasi fully responsive untuk:
- 📱 Mobile (< 600px)
- 📱 Tablet (600px - 900px)
- 💻 Desktop (> 900px)

---

## 🔒 Keamanan

- ✅ Prepared statements (PDO)
- ✅ Password hashing (bcrypt)
- ✅ Session management
- ✅ XSS protection
- ✅ SQL injection prevention
- ✅ Input validation

---

## 🐛 Troubleshooting

### Audio tidak keluar:
- Cek file audio sudah diupload
- Cek format file (mp3, wav, ogg)
- Cek permission browser untuk audio

### Speech Recognition tidak work:
- Gunakan Chrome atau Edge
- Izinkan akses microphone
- Cek koneksi internet (API butuh online)

### Gambar tidak muncul:
- Cek path gambar di database
- Cek file gambar sudah diupload
- Cek format file (jpg, png, gif)

---

## 📈 Roadmap & Improvement Ideas

### Phase 1 (Done):
- ✅ Landing page
- ✅ Vocabulary with flashcards
- ✅ Listening with audio player
- ✅ Quiz with 5 types
- ✅ Admin panel
- ✅ Database structure

### Phase 2 (Future):
- [ ] User registration system
- [ ] Progress tracking per student
- [ ] Gamification (badges, achievements)
- [ ] Leaderboard per kelas
- [ ] Export progress report
- [ ] Mobile app (React Native / Flutter)

### Phase 3 (Advanced):
- [ ] AI-powered pronunciation assessment
- [ ] Adaptive learning path
- [ ] Multiplayer quiz mode
- [ ] Video lessons
- [ ] Parent dashboard

---

## 👥 Credit

**Developer**: [Your Name]
**Design Inspiration**: Duolingo
**Font**: Fredoka by Google Fonts
**Icons**: Font Awesome

---

## 📄 License

This project is for educational purposes.

---

## 📞 Support

Untuk bantuan atau pertanyaan:
- Email: support@funlish.com
- Documentation: README.md

---

**Happy Learning! 🚀📚**
