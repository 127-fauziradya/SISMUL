<?php
require_once '../../config.php';

$db = getDB();

try {
    $stmt = $db->query("SELECT COUNT(*) as count FROM soal");
    $result = $stmt->fetch();
    
    jsonResponse([
        'success' => true,
        'count' => $result['count']
    ]);
} catch(Exception $e) {
    jsonResponse([
        'success' => false,
        'message' => $e->getMessage()
    ], 500);
}
?>
