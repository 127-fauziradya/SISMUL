<?php
require_once '../config.php';

$db = getDB();
$id_kelas = $_GET['id_kelas'] ?? null;
$id_level = $_GET['id_level'] ?? null;

if (!$id_kelas) {
    jsonResponse([
        'success' => false,
        'message' => 'ID kelas harus diisi'
    ], 400);
}

try {
    $sql = "SELECT q.*, l.nama_level 
            FROM quiz q 
            JOIN level_quiz l ON q.id_level = l.id_level 
            WHERE q.id_kelas = :id_kelas";
    
    if ($id_level) {
        $sql .= " AND q.id_level = :id_level";
    }
    
    $sql .= " ORDER BY q.id_level ASC";
    
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':id_kelas', $id_kelas);
    
    if ($id_level) {
        $stmt->bindParam(':id_level', $id_level);
    }
    
    $stmt->execute();
    $quiz = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'data' => $quiz
    ]);
} catch(Exception $e) {
    jsonResponse([
        'success' => false,
        'message' => $e->getMessage()
    ], 500);
}
?>
