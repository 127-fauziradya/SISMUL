<?php
require_once '../config.php';

$db = getDB();
$id_materi = $_GET['id_materi'] ?? null;

if (!$id_materi) {
    jsonResponse([
        'success' => false,
        'message' => 'ID materi harus diisi'
    ], 400);
}

try {
    $stmt = $db->prepare("SELECT * FROM vocabulary WHERE id_materi = :id_materi ORDER BY id_vocab ASC");
    $stmt->bindParam(':id_materi', $id_materi);
    $stmt->execute();
    
    $vocabulary = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'data' => $vocabulary
    ]);
} catch(Exception $e) {
    jsonResponse([
        'success' => false,
        'message' => $e->getMessage()
    ], 500);
}
?>
