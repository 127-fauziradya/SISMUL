<?php
require_once '../config.php';

$db = getDB();
$id_kelas = $_GET['id_kelas'] ?? null;
$kategori = $_GET['kategori'] ?? null;

if (!$id_kelas) {
    jsonResponse([
        'success' => false,
        'message' => 'ID kelas harus diisi'
    ], 400);
}

try {
    $sql = "SELECT * FROM materi WHERE id_kelas = :id_kelas";
    
    if ($kategori) {
        $sql .= " AND kategori = :kategori";
    }
    
    $sql .= " ORDER BY created_at DESC";
    
    $stmt = $db->prepare($sql);
    $stmt->bindParam(':id_kelas', $id_kelas);
    
    if ($kategori) {
        $stmt->bindParam(':kategori', $kategori);
    }
    
    $stmt->execute();
    $materi = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'data' => $materi
    ]);
} catch(Exception $e) {
    jsonResponse([
        'success' => false,
        'message' => $e->getMessage()
    ], 500);
}
?>
