<?php
require_once '../config.php';

$db = getDB();
$id_materi = $_GET['id_materi'] ?? null;

if (!$id_materi) {
    jsonResponse([
        'success' => false,
        'message' => 'ID materi harus diisi'
    ], 400);
}

try {
    $stmt = $db->prepare("SELECT * FROM listening WHERE id_materi = :id_materi ORDER BY id_listening ASC");
    $stmt->bindParam(':id_materi', $id_materi);
    $stmt->execute();
    
    $listening = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'data' => $listening
    ]);
} catch(Exception $e) {
    jsonResponse([
        'success' => false,
        'message' => $e->getMessage()
    ], 500);
}
?>
