<?php
require_once '../config.php';

$db = getDB();

try {
    $stmt = $db->query("SELECT * FROM kelas ORDER BY id_kelas ASC");
    $kelas = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'data' => $kelas
    ]);
} catch(Exception $e) {
    jsonResponse([
        'success' => false,
        'message' => $e->getMessage()
    ], 500);
}
?>
