<?php
require_once '../config.php';

$db = getDB();
$id_quiz = $_GET['id_quiz'] ?? null;

if (!$id_quiz) {
    jsonResponse([
        'success' => false,
        'message' => 'ID quiz harus diisi'
    ], 400);
}

try {
    // Get soal
    $stmt = $db->prepare("SELECT * FROM soal WHERE id_quiz = :id_quiz ORDER BY id_soal ASC");
    $stmt->bindParam(':id_quiz', $id_quiz);
    $stmt->execute();
    $soal = $stmt->fetchAll();
    
    // Get opsi jawaban untuk setiap soal
    foreach ($soal as &$s) {
        $stmtOpsi = $db->prepare("SELECT * FROM opsi_jawaban WHERE id_soal = :id_soal ORDER BY id_opsi ASC");
        $stmtOpsi->bindParam(':id_soal', $s['id_soal']);
        $stmtOpsi->execute();
        $s['opsi'] = $stmtOpsi->fetchAll();
    }
    
    jsonResponse([
        'success' => true,
        'data' => $soal
    ]);
} catch(Exception $e) {
    jsonResponse([
        'success' => false,
        'message' => $e->getMessage()
    ], 500);
}
?>
