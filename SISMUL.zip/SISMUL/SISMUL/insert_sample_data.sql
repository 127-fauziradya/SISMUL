-- Insert Sample Data untuk FUNLISH

USE db_funlish;

-- Insert Kelas
INSERT INTO kelas (id_kelas, nama_kelas) VALUES
(3, 'Kelas 3'),
(4, 'Kelas 4'),
(5, 'Kelas 5'),
(6, 'Kelas 6');

-- Insert Level Quiz
INSERT INTO level_quiz (id_level, nama_level) VALUES
(1, 'Level 1'),
(2, 'Level 2'),
(3, 'Level 3');

-- Insert Admin (password: admin123)
INSERT INTO admin (username, password, nama_admin) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator');

-- Insert Materi untuk Kelas 3 - Vocabulary
INSERT INTO materi (id_kelas, judul, kategori, deskripsi) VALUES
(3, 'Colors and Numbers', 'vocabulary', 'Belajar warna dan angka dalam Bahasa Inggris');

-- Insert Vocabulary untuk Kelas 3
INSERT INTO vocabulary (id_materi, kata_inggris, arti_indonesia, gambar, audio) VALUES
(1, 'Red', 'Merah', 'assets/images/red.jpg', 'assets/audio/red.mp3'),
(1, 'Blue', 'Biru', 'assets/images/blue.jpg', 'assets/audio/blue.mp3'),
(1, 'Green', 'Hijau', 'assets/images/green.jpg', 'assets/audio/green.mp3'),
(1, 'Yellow', 'Kuning', 'assets/images/yellow.jpg', 'assets/audio/yellow.mp3'),
(1, 'One', 'Satu', 'assets/images/one.jpg', 'assets/audio/one.mp3'),
(1, 'Two', 'Dua', 'assets/images/two.jpg', 'assets/audio/two.mp3'),
(1, 'Three', 'Tiga', 'assets/images/three.jpg', 'assets/audio/three.mp3'),
(1, 'Four', 'Empat', 'assets/images/four.jpg', 'assets/audio/four.mp3');

-- Insert Materi untuk Kelas 3 - Listening
INSERT INTO materi (id_kelas, judul, kategori, deskripsi) VALUES
(3, 'Simple Greetings', 'listening', 'Mendengarkan sapaan sederhana dalam Bahasa Inggris');

-- Insert Listening untuk Kelas 3
INSERT INTO listening (id_materi, audio_file, transcript) VALUES
(2, 'assets/audio/greeting1.mp3', 'Hello! Good morning. How are you today?'),
(2, 'assets/audio/greeting2.mp3', 'Hi! My name is Sarah. What is your name?');

-- Insert Quiz Level 1 untuk Kelas 3
INSERT INTO quiz (id_kelas, id_level, judul_quiz) VALUES
(3, 1, 'Colors Quiz - Level 1');

-- Insert Soal Vocabulary Matching
INSERT INTO soal (id_quiz, tipe_soal, pertanyaan, gambar, jawaban_benar, pembahasan) VALUES
(1, 'vocabulary', 'What color is this?', 'assets/images/apple.jpg', NULL, 'Apel berwarna merah (red)');

INSERT INTO opsi_jawaban (id_soal, opsi, is_benar) VALUES
(1, 'Red', 1),
(1, 'Blue', 0),
(1, 'Green', 0),
(1, 'Yellow', 0);

-- Insert Soal Reading Comprehension
INSERT INTO soal (id_quiz, tipe_soal, pertanyaan, jawaban_benar, pembahasan) VALUES
(1, 'reading', 'Read the sentence: "The sky is blue." What color is the sky?', NULL, 'Langit berwarna biru (blue) sesuai dengan kalimat yang diberikan');

INSERT INTO opsi_jawaban (id_soal, opsi, is_benar) VALUES
(2, 'Red', 0),
(2, 'Blue', 1),
(2, 'Green', 0),
(2, 'Yellow', 0);

-- Insert Soal Listening Comprehension
INSERT INTO soal (id_quiz, tipe_soal, pertanyaan, audio, jawaban_benar, pembahasan) VALUES
(1, 'listening', 'Listen to the audio. What color is mentioned?', 'assets/audio/color_red.mp3', NULL, 'Audio menyebutkan warna merah (red)');

INSERT INTO opsi_jawaban (id_soal, opsi, is_benar) VALUES
(3, 'Red', 1),
(3, 'Blue', 0),
(3, 'Green', 0),
(3, 'Yellow', 0);

-- Insert Soal Speaking Assessment
INSERT INTO soal (id_quiz, tipe_soal, pertanyaan, jawaban_benar, pembahasan) VALUES
(1, 'speaking', 'Say the word: GREEN', 'green', 'Ucapkan kata "green" dengan jelas');

-- Insert Soal Memorizing via Image
INSERT INTO soal (id_quiz, tipe_soal, pertanyaan, gambar, jawaban_benar, pembahasan) VALUES
(1, 'memorizing', 'Look at the image. What is this fruit called in English?', 'assets/images/banana.jpg', 'banana', 'Buah ini adalah pisang (banana) dalam Bahasa Inggris');

-- Commit
COMMIT;
