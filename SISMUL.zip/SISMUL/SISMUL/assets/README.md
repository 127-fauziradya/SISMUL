# 📁 Assets Folder

Folder ini berisi media file untuk aplikasi FUNLISH.

## 📂 Struktur Folder

```
assets/
├── images/          # Gambar untuk vocabulary dan soal quiz
│   ├── red.jpg
│   ├── blue.jpg
│   ├── apple.jpg
│   ├── banana.jpg
│   └── ...
│
└── audio/           # File audio untuk listening dan pronunciation
    ├── red.mp3
    ├── greeting1.mp3
    ├── color_red.mp3
    └── ...
```

## 🎨 Format File yang Didukung

### Images:
- `.jpg` / `.jpeg`
- `.png`
- `.gif`
- `.webp`

**Rekomendasi:**
- Ukuran: 500x500px atau 800x600px
- Format: JPG untuk foto, PNG untuk gambar dengan transparansi
- Ukuran file: Maksimal 500KB per gambar

### Audio:
- `.mp3` (recommended)
- `.wav`
- `.ogg`

**Rekomendasi:**
- Bitrate: 128kbps
- Sample rate: 44.1kHz
- Mono atau Stereo
- Ukuran file: Maksimal 2MB per audio

## 📥 Cara Upload File

### Via Admin Panel (Recommended):
1. Login ke admin panel
2. Pilih menu yang sesuai (Vocabulary/Listening/Soal)
3. Klik "Tambah Baru"
4. Upload file melalui form
5. File akan otomatis tersimpan di folder ini

### Via Manual Upload:
1. Copy file ke folder `assets/images/` atau `assets/audio/`
2. Pastikan nama file sesuai dengan yang ada di database
3. Contoh: `assets/images/apple.jpg`

## 🗄️ Naming Convention

### Images:
- Gunakan lowercase
- Pisahkan dengan underscore
- Contoh: `red_apple.jpg`, `number_one.png`

### Audio:
- Gunakan lowercase
- Pisahkan dengan underscore
- Contoh: `greeting_hello.mp3`, `color_red.mp3`

## 💾 Sample Data

Untuk testing, gunakan gambar dan audio dari:
- **Free Stock Photos**: Unsplash, Pexels, Pixabay
- **Free Audio**: Freesound.org, Audio Library YouTube
- **Text-to-Speech**: Google TTS, Amazon Polly

## ⚠️ Copyright Notice

Pastikan semua media file yang diupload:
- ✅ Memiliki lisensi free/open source
- ✅ Atau dibuat sendiri
- ❌ Jangan gunakan copyrighted material

## 🔒 Security

- File akan dicek extension-nya oleh sistem
- Hanya file gambar dan audio yang diizinkan
- File akan di-sanitize nama filenya
- File berbahaya akan ditolak

## 📊 Storage Recommendation

Untuk produksi dengan banyak konten:
- Gunakan CDN (CloudFlare, AWS S3)
- Compress gambar (TinyPNG, ImageOptim)
- Compress audio (Audacity, MP3 Compressor)
- Backup regular ke external storage

---

**Folder ini siap digunakan!** 📁✨
