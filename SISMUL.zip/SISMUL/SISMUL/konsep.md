Buatkan konsep aplikasi/media pembelajaran Bahasa Inggris berbasis web untuk siswa SD kelas 3–6.



Struktur Sistem

Pembelajaran dibagi berdasarkan kelas:

Kelas 3

Kelas 4

Kelas 5

Kelas 6

Setiap kelas memiliki menu:

Vocabulary

Listening

Quiz

Struktur Quiz

Quiz terdiri dari 3 level:

Level 1

Level 2

Level 3

Setiap level berisi beberapa jenis soal:

1. Vocabulary Matching

Siswa mencocokkan kosakata Bahasa Inggris dengan arti Bahasa Indonesianya.

2. Reading Comprehension

Siswa membaca teks atau soal.

Siswa memilih kesimpulan/jawaban yang paling tepat berdasarkan bacaan.

3. Listening Comprehension

Siswa mendengarkan audio.

Siswa memilih kesimpulan/jawaban yang paling tepat berdasarkan audio yang didengar.

4. Speaking Assessment

Siswa diminta mengucapkan vocabulary tertentu.

Sistem menilai kesesuaian pelafalan menggunakan Web Speech API (Speech Recognition).

5. Memorizing via Image

Sistem menampilkan gambar yang berisi objek, aktivitas, atau situasi tertentu.

Siswa diminta menuliskan atau memilih kosakata Bahasa Inggris yang sesuai dengan gambar.

Aturan Quiz

Jika siswa menjawab salah, sistem langsung menampilkan jawaban yang benar.

Level yang tersedia langsung terbuka tanpa sistem unlock.

Tidak ada sistem ranking.

Tidak ada sistem poin atau reward yang kompleks (kecuali jika diperlukan dalam konsep).

Tujuan Sistem

Membantu siswa SD kelas 3–6 meningkatkan kemampuan:

Vocabulary

Reading

Listening

Speaking

Memorization

Output yang Diharapkan dari AI



Buatkan:



Konsep website secara lengkap.

Alur penggunaan siswa.

Struktur menu dan fitur.

Sesuaikan dengan database yang sudah ada

Use case dan flowchart sistem.

Wireframe/dashboard utama.

Skenario quiz untuk setiap jenis soal sama seperti duolingo