<?php
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$admin_name = $_SESSION['admin_name'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Panel - FUNLISH</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Fredoka', sans-serif;
      background: #f3f4f6;
    }

    .sidebar {
      width: 250px;
      height: 100vh;
      background: #1f2937;
      position: fixed;
      left: 0;
      top: 0;
      padding: 30px 20px;
    }

    .logo {
      color: white;
      font-size: 1.8rem;
      font-weight: 700;
      margin-bottom: 40px;
      text-align: center;
    }

    .menu-item {
      color: #9ca3af;
      padding: 15px 20px;
      border-radius: 10px;
      display: flex;
      align-items: center;
      gap: 15px;
      text-decoration: none;
      transition: 0.3s;
      margin-bottom: 10px;
      font-weight: 500;
    }

    .menu-item:hover, .menu-item.active {
      background: #374151;
      color: white;
    }

    .menu-item i {
      width: 20px;
    }

    .main-content {
      margin-left: 250px;
      padding: 40px;
    }

    .header {
      background: white;
      padding: 25px 30px;
      border-radius: 15px;
      margin-bottom: 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .header h1 {
      color: #1f2937;
      font-size: 2rem;
    }

    .admin-info {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .logout-btn {
      padding: 10px 25px;
      background: #e91e63;
      color: white;
      border: none;
      border-radius: 50px;
      font-family: 'Fredoka', sans-serif;
      font-weight: 600;
      cursor: pointer;
      transition: 0.3s;
      text-decoration: none;
    }

    .logout-btn:hover {
      background: #c2185b;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }

    .stat-card {
      background: white;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .stat-card .icon {
      width: 60px;
      height: 60px;
      border-radius: 15px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 1.8rem;
      color: white;
      margin-bottom: 20px;
    }

    .stat-card h3 {
      color: #6b7280;
      font-size: 0.9rem;
      margin-bottom: 10px;
      font-weight: 500;
    }

    .stat-card .value {
      color: #1f2937;
      font-size: 2.5rem;
      font-weight: 700;
    }

    .card {
      background: white;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
      margin-bottom: 20px;
    }

    .card h2 {
      color: #1f2937;
      margin-bottom: 20px;
    }

    .btn {
      padding: 12px 30px;
      border: none;
      border-radius: 50px;
      font-family: 'Fredoka', sans-serif;
      font-weight: 600;
      cursor: pointer;
      transition: 0.3s;
      text-decoration: none;
      display: inline-block;
    }

    .btn-primary {
      background: #58cc02;
      color: white;
    }

    .btn-primary:hover {
      background: #45a000;
    }
  </style>
</head>
<body>
  
  <div class="sidebar">
    <div class="logo">FUNLISH</div>
    
    <a href="index.php" class="menu-item active">
      <i class="fa-solid fa-home"></i>
      Dashboard
    </a>
    
    <a href="manage-materi.php" class="menu-item">
      <i class="fa-solid fa-book"></i>
      Materi
    </a>
    
    <a href="manage-vocabulary.php" class="menu-item">
      <i class="fa-solid fa-language"></i>
      Vocabulary
    </a>
    
    <a href="manage-listening.php" class="menu-item">
      <i class="fa-solid fa-headphones"></i>
      Listening
    </a>
    
    <a href="manage-quiz.php" class="menu-item">
      <i class="fa-solid fa-gamepad"></i>
      Quiz
    </a>
    
    <a href="manage-soal.php" class="menu-item">
      <i class="fa-solid fa-question-circle"></i>
      Soal Quiz
    </a>
  </div>

  <div class="main-content">
    
    <div class="header">
      <h1>Dashboard Admin</h1>
      <div class="admin-info">
        <span style="color: #6b7280;">Halo, <strong><?php echo htmlspecialchars($admin_name); ?></strong></span>
        <a href="logout.php" class="logout-btn">
          <i class="fa-solid fa-sign-out"></i>
          Logout
        </a>
      </div>
    </div>

    <div class="stats-grid">
      
      <div class="stat-card">
        <div class="icon" style="background: #58cc02;">
          <i class="fa-solid fa-book"></i>
        </div>
        <h3>Total Materi</h3>
        <div class="value" id="totalMateri">0</div>
      </div>

      <div class="stat-card">
        <div class="icon" style="background: #ff9500;">
          <i class="fa-solid fa-language"></i>
        </div>
        <h3>Total Vocabulary</h3>
        <div class="value" id="totalVocab">0</div>
      </div>

      <div class="stat-card">
        <div class="icon" style="background: #e91e63;">
          <i class="fa-solid fa-gamepad"></i>
        </div>
        <h3>Total Quiz</h3>
        <div class="value" id="totalQuiz">0</div>
      </div>

      <div class="stat-card">
        <div class="icon" style="background: #667eea;">
          <i class="fa-solid fa-question-circle"></i>
        </div>
        <h3>Total Soal</h3>
        <div class="value" id="totalSoal">0</div>
      </div>

    </div>

    <div class="card">
      <h2>Quick Actions</h2>
      <div style="display: flex; gap: 15px; flex-wrap: wrap;">
        <a href="manage-materi.php" class="btn btn-primary">
          <i class="fa-solid fa-plus"></i> Tambah Materi
        </a>
        <a href="manage-vocabulary.php" class="btn btn-primary">
          <i class="fa-solid fa-plus"></i> Tambah Vocabulary
        </a>
        <a href="manage-quiz.php" class="btn btn-primary">
          <i class="fa-solid fa-plus"></i> Tambah Quiz
        </a>
      </div>
    </div>

  </div>

  <script>
    // Load statistics
    async function loadStats() {
      try {
        const [materiRes, vocabRes, quizRes, soalRes] = await Promise.all([
          fetch('../api/get_materi.php?id_kelas=1'),
          fetch('../api/admin/count_vocabulary.php'),
          fetch('../api/admin/count_quiz.php'),
          fetch('../api/admin/count_soal.php')
        ]);

        const [materiData, vocabData, quizData, soalData] = await Promise.all([
          materiRes.json(),
          vocabRes.json(),
          quizRes.json(),
          soalRes.json()
        ]);

        if (vocabData.success) document.getElementById('totalVocab').textContent = vocabData.count;
        if (quizData.success) document.getElementById('totalQuiz').textContent = quizData.count;
        if (soalData.success) document.getElementById('totalSoal').textContent = soalData.count;
        
      } catch (error) {
        console.error('Error loading stats:', error);
      }
    }

    loadStats();
  </script>

</body>
</html>
