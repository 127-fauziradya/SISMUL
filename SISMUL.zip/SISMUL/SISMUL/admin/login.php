<?php
require_once '../config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($username && $password) {
        try {
            $db = getDB();
            $stmt = $db->prepare("SELECT * FROM admin WHERE username = :username");
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            
            $admin = $stmt->fetch();
            
            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id_admin'];
                $_SESSION['admin_name'] = $admin['nama_admin'];
                header('Location: index.php');
                exit;
            } else {
                $error = 'Username atau password salah';
            }
        } catch(Exception $e) {
            $error = 'Terjadi kesalahan sistem';
        }
    } else {
        $error = 'Username dan password harus diisi';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login Admin - FUNLISH</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Fredoka', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }

    .login-card {
      background: white;
      padding: 50px;
      border-radius: 30px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      width: 100%;
      max-width: 450px;
    }

    .logo {
      text-align: center;
      font-size: 3rem;
      font-weight: 700;
      color: #667eea;
      margin-bottom: 10px;
    }

    .subtitle {
      text-align: center;
      color: #6b7280;
      margin-bottom: 40px;
    }

    .form-group {
      margin-bottom: 25px;
    }

    label {
      display: block;
      color: #1f2937;
      font-weight: 600;
      margin-bottom: 10px;
    }

    input {
      width: 100%;
      padding: 15px 20px;
      border: 2px solid #e5e7eb;
      border-radius: 15px;
      font-family: 'Fredoka', sans-serif;
      font-size: 1rem;
      transition: 0.3s;
    }

    input:focus {
      outline: none;
      border-color: #667eea;
    }

    .error {
      background: #fce4ec;
      color: #c2185b;
      padding: 15px;
      border-radius: 10px;
      margin-bottom: 20px;
      text-align: center;
    }

    .btn-login {
      width: 100%;
      padding: 18px;
      background: #667eea;
      border: none;
      border-radius: 15px;
      color: white;
      font-family: 'Fredoka', sans-serif;
      font-size: 1.1rem;
      font-weight: 700;
      cursor: pointer;
      transition: 0.3s;
    }

    .btn-login:hover {
      background: #5568d3;
      transform: translateY(-2px);
    }

    .back-home {
      text-align: center;
      margin-top: 20px;
    }

    .back-home a {
      color: #667eea;
      text-decoration: none;
      font-weight: 600;
    }

    .back-home a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  
  <div class="login-card">
    <div class="logo">FUNLISH</div>
    <p class="subtitle">Admin Panel</p>

    <?php if ($error): ?>
      <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" required>
      </div>

      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" required>
      </div>

      <button type="submit" class="btn-login">Login</button>
    </form>

    <div class="back-home">
      <a href="../index.html">← Kembali ke Beranda</a>
    </div>
  </div>

</body>
</html>
