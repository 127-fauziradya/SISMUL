# 📖 DOKUMENTASI LENGKAP FUNLISH

## 🎯 Konsep Website

### Visi
Membuat pembelajaran Bahasa Inggris menjadi menyenangkan dan interaktif untuk siswa SD kelas 3-6 melalui pendekatan gamifikasi dan multimedia.

### Misi
- Meningkatkan kemampuan vocabulary siswa
- Melatih listening comprehension
- Mengembangkan speaking skills melalui teknologi
- Membangun reading comprehension
- Meningkatkan daya ingat melalui visual learning

---

## 🔄 Alur Penggunaan Siswa

### 1. Landing Page (index.html)
```
Siswa membuka website
    ↓
Melihat hero section dengan tagline menarik
    ↓
Scroll ke section "Pilih Kelas"
    ↓
Klik tombol "Masuk Kelas" pada kelas yang sesuai
    ↓
ATAU
    ↓
Klik icon buku di navbar untuk modal pilih kelas
```

### 2. Dashboard Kelas (class-dashboard.html)
```
Siswa masuk ke dashboard kelas
    ↓
Melihat 3 menu utama:
  - Vocabulary
  - Listening  
  - Quiz
    ↓
Memilih menu pembelajaran yang diinginkan
```

### 3. Flow Vocabulary
```
Klik menu Vocabulary
    ↓
Sistem load vocabulary dari database
    ↓
Tampilkan flashcard dengan:
  - Gambar
  - Kata Bahasa Inggris
  - Tombol audio
    ↓
Siswa klik kartu → Flip → Lihat arti Indonesia
    ↓
Siswa klik audio → Dengar pelafalan
    ↓
Siswa klik "Selanjutnya" → Kartu berikutnya
    ↓
Selesai semua → Konfirmasi → Kembali ke dashboard
```

### 4. Flow Listening
```
Klik menu Listening
    ↓
Sistem load audio dari database
    ↓
Tampilkan audio player
    ↓
Siswa klik play → Audio dimainkan
    ↓
Siswa bisa:
  - Pause/play ulang
  - Lihat transkrip
    ↓
Siswa klik "Selanjutnya" → Audio berikutnya
    ↓
Selesai semua → Konfirmasi → Kembali ke dashboard
```

### 5. Flow Quiz
```
Klik menu Quiz
    ↓
Pilih level (1, 2, atau 3)
    ↓
Sistem load quiz sesuai level
    ↓
Tampilkan list quiz yang tersedia
    ↓
Siswa klik salah satu quiz
    ↓
Masuk ke quiz-play.html
    ↓
Sistem load soal dari database
    ↓
Tampilkan soal pertama sesuai tipe:

TIPE 1: Vocabulary Matching
    ↓
  Lihat gambar/pertanyaan
    ↓
  Pilih jawaban dari 4 opsi
    ↓
  Klik "Cek Jawaban"
    ↓
  Lihat feedback (benar/salah)
    ↓
  Jika salah → Lihat jawaban yang benar
    ↓
  Klik "Lanjut"

TIPE 2: Reading Comprehension
    ↓
  Baca teks/kalimat
    ↓
  Pilih jawaban dari opsi
    ↓
  Cek jawaban
    ↓
  Lihat pembahasan
    ↓
  Lanjut

TIPE 3: Listening Comprehension
    ↓
  Dengarkan audio (bisa diulang)
    ↓
  Pilih jawaban berdasarkan audio
    ↓
  Cek jawaban
    ↓
  Lihat feedback
    ↓
  Lanjut

TIPE 4: Speaking Assessment
    ↓
  Lihat kata yang harus diucapkan
    ↓
  Klik mikrofon
    ↓
  Ucapkan kata
    ↓
  Sistem mendengarkan (Speech Recognition)
    ↓
  Sistem bandingkan dengan jawaban
    ↓
  Tampilkan hasil (benar/coba lagi)
    ↓
  Lanjut

TIPE 5: Memorizing via Image
    ↓
  Lihat gambar
    ↓
  Ketik jawaban di input field
    ↓
  Klik "Cek Jawaban"
    ↓
  Sistem cek (case-insensitive)
    ↓
  Tampilkan feedback
    ↓
  Lanjut

Loop untuk semua soal
    ↓
Selesai semua soal
    ↓
Tampilkan konfirmasi
    ↓
Kembali ke halaman quiz (pilih level)
```

---

## 🗂️ Struktur Menu dan Fitur

### Menu Utama (Student View)
```
FUNLISH (Landing Page)
│
├─ Hero Section
│  ├─ Tagline
│  ├─ Deskripsi
│  └─ CTA Button
│
├─ Pilih Kelas Section
│  ├─ Kelas 3
│  ├─ Kelas 4
│  ├─ Kelas 5
│  └─ Kelas 6
│
└─ Metode Belajar Section
   ├─ Vocabulary
   ├─ Speaking
   └─ Quiz

Dashboard Kelas (Setelah pilih kelas)
│
├─ Vocabulary
│  ├─ Flashcard System
│  ├─ Image Display
│  ├─ Audio Pronunciation
│  ├─ Flip Animation
│  └─ Progress Tracking
│
├─ Listening
│  ├─ Audio Player
│  ├─ Play/Pause Control
│  ├─ Transcript Toggle
│  └─ Progress Tracking
│
└─ Quiz
   ├─ Level Selector
   │  ├─ Level 1
   │  ├─ Level 2
   │  └─ Level 3
   │
   └─ Quiz List
      ├─ Quiz 1
      ├─ Quiz 2
      └─ Quiz 3
         │
         └─ Soal (5 Tipe)
            ├─ Vocabulary Matching
            ├─ Reading Comprehension
            ├─ Listening Comprehension
            ├─ Speaking Assessment
            └─ Memorizing via Image
```

### Menu Admin (Admin Panel)
```
Admin Panel
│
├─ Dashboard
│  ├─ Statistics Cards
│  │  ├─ Total Materi
│  │  ├─ Total Vocabulary
│  │  ├─ Total Quiz
│  │  └─ Total Soal
│  └─ Quick Actions
│
├─ Manage Materi
│  ├─ Tambah Materi Baru
│  ├─ Edit Materi
│  └─ Hapus Materi
│
├─ Manage Vocabulary
│  ├─ Tambah Vocabulary
│  ├─ Upload Gambar
│  ├─ Upload Audio
│  ├─ Edit Vocabulary
│  └─ Hapus Vocabulary
│
├─ Manage Listening
│  ├─ Tambah Audio
│  ├─ Upload File Audio
│  ├─ Input Transkrip
│  ├─ Edit Listening
│  └─ Hapus Listening
│
├─ Manage Quiz
│  ├─ Tambah Quiz
│  ├─ Pilih Kelas
│  ├─ Pilih Level
│  ├─ Edit Quiz
│  └─ Hapus Quiz
│
└─ Manage Soal
   ├─ Tambah Soal
   ├─ Pilih Quiz
   ├─ Pilih Tipe Soal
   ├─ Input Pertanyaan
   ├─ Upload Media (gambar/audio)
   ├─ Input Opsi Jawaban
   ├─ Tandai Jawaban Benar
   ├─ Input Pembahasan
   ├─ Edit Soal
   └─ Hapus Soal
```

---

## 🗄️ Database Sesuai Konsep

### Tabel dan Relasi

```
kelas (id_kelas, nama_kelas)
    ↓ (1 to many)
materi (id_materi, id_kelas, judul, kategori, deskripsi)
    ↓ (1 to many)
    ├─→ vocabulary (id_vocab, id_materi, kata_inggris, arti_indonesia, gambar, audio)
    └─→ listening (id_listening, id_materi, audio_file, transcript)

kelas (id_kelas)
    ↓ (1 to many)
quiz (id_quiz, id_kelas, id_level, judul_quiz)
    ↓ (1 to many)
soal (id_soal, id_quiz, tipe_soal, pertanyaan, gambar, audio, jawaban_benar, pembahasan)
    ↓ (1 to many)
opsi_jawaban (id_opsi, id_soal, opsi, is_benar)

level_quiz (id_level, nama_level)
    ↓ (1 to many)
quiz (id_quiz, id_level)

admin (id_admin, username, password, nama_admin)
```

### Enum Tipe Soal:
- `vocabulary`: Vocabulary Matching
- `reading`: Reading Comprehension
- `listening`: Listening Comprehension
- `speaking`: Speaking Assessment
- `memorizing`: Memorizing via Image

### Enum Kategori Materi:
- `vocabulary`: Materi kosakata
- `listening`: Materi mendengarkan

---

## 📊 Use Case Diagram

```
┌─────────────┐
│   Siswa     │
└──────┬──────┘
       │
       ├──────→ Pilih Kelas
       │            │
       │            ├──→ Akses Vocabulary
       │            │       └──→ Lihat Flashcard
       │            │       └──→ Dengar Audio
       │            │       └──→ Flip Card
       │            │
       │            ├──→ Akses Listening
       │            │       └──→ Play Audio
       │            │       └──→ Lihat Transkrip
       │            │
       │            └──→ Akses Quiz
       │                    └──→ Pilih Level
       │                    └──→ Kerjakan Soal
       │                    └──→ Lihat Feedback
       │
┌──────┴──────┐
│   Admin     │
└──────┬──────┘
       │
       ├──────→ Login
       │
       ├──────→ Manage Materi
       │            └──→ CRUD Materi
       │
       ├──────→ Manage Vocabulary
       │            └──→ CRUD Vocabulary
       │            └──→ Upload Media
       │
       ├──────→ Manage Listening
       │            └──→ CRUD Listening
       │            └──→ Upload Audio
       │
       ├──────→ Manage Quiz
       │            └──→ CRUD Quiz
       │
       ├──────→ Manage Soal
       │            └──→ CRUD Soal
       │            └──→ CRUD Opsi Jawaban
       │
       └──────→ Lihat Statistik
```

---

## 🔄 Flowchart Sistem Quiz

```
[Start]
    ↓
[Pilih Kelas]
    ↓
[Pilih Menu Quiz]
    ↓
[Pilih Level (1/2/3)]
    ↓
[Load Quiz dari Database]
    ↓
[Tampilkan List Quiz] ← ─ ─ ─ ┐
    ↓                         │
[Siswa Pilih Quiz]            │
    ↓                         │
[Load Soal dari Database]     │
    ↓                         │
[Index = 0]                   │
    ↓                         │
┌───────────────────┐         │
│ Tampilkan Soal[i] │         │
└─────────┬─────────┘         │
          ↓                   │
    [Cek Tipe Soal]           │
          ↓                   │
    ┌─────┴─────┐             │
    │           │             │
[Vocabulary/ [Listening/      │
 Reading]     Speaking/       │
    │        Memorizing]      │
    ↓             ↓           │
[Tampilkan  [Tampilkan        │
 Opsi]       Interface]       │
    ↓             ↓           │
[Siswa      [Siswa            │
 Pilih]      Interaksi]       │
    ↓             ↓           │
[Klik Cek]  [Proses Input]    │
    ↓             ↓           │
    └──────┬──────┘           │
           ↓                  │
    [Cek Jawaban]             │
           ↓                  │
    ┌─────┴─────┐             │
    │           │             │
 [Benar]    [Salah]           │
    │           │             │
    └─────┬─────┘             │
          ↓                   │
 [Tampilkan Feedback]         │
          ↓                   │
 [Tampilkan Pembahasan]       │
          ↓                   │
    [Klik Lanjut]             │
          ↓                   │
    [Index++]                 │
          ↓                   │
    <Index < Total Soal?>     │
          ↓                   │
      Yes │ No                │
          │  ↓                │
          │ [Quiz Selesai]    │
          │  ↓                │
          │ [Tampilkan        │
          │  Konfirmasi]      │
          │  ↓                │
          └──────────────────→┘
               
[End]
```

---

## 🎨 Wireframe Dashboard Utama

```
┌────────────────────────────────────────────────────────────┐
│  [☰]              FUNLISH                         [📖] [👤] │
├────────────────────────────────────────────────────────────┤
│                                                              │
│                    ╔══════════════════╗                     │
│                    ║                  ║                     │
│                    ║   HERO IMAGE     ║                     │
│                    ║                  ║                     │
│                    ╚══════════════════╝                     │
│                                                              │
│              LET'S LEARN ENGLISH FUN!                        │
│                                                              │
│        Belajar kosa kata, grammar, dan latihan seru         │
│                                                              │
│          [Mulai Belajar]  [Lihat Metode]                    │
│                                                              │
├────────────────────────────────────────────────────────────┤
│                      PILIH KELAS                             │
│                                                              │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐       │
│  │   📘    │  │   📗    │  │   📙    │  │   📕    │       │
│  │ Kelas 3 │  │ Kelas 4 │  │ Kelas 5 │  │ Kelas 6 │       │
│  │         │  │         │  │         │  │         │       │
│  │ [Masuk] │  │ [Masuk] │  │ [Masuk] │  │ [Masuk] │       │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘       │
│                                                              │
├────────────────────────────────────────────────────────────┤
│                    METODE BELAJAR                            │
│                                                              │
│    ┌──────────┐      ┌──────────┐      ┌──────────┐        │
│    │    🗣️    │      │    🎤    │      │    📝    │        │
│    │Vocabulary│      │ Speaking │      │   Quiz   │        │
│    │          │      │          │      │          │        │
│    └──────────┘      └──────────┘      └──────────┘        │
│                                                              │
└────────────────────────────────────────────────────────────┘
```

### Wireframe Dashboard Kelas
```
┌────────────────────────────────────────────────────────────┐
│  [← Kembali]                                                │
├────────────────────────────────────────────────────────────┤
│                         KELAS 3                              │
│         Pilih menu pembelajaran yang ingin dipelajari        │
│                                                              │
│  ┌─────────────────────────────────────────────────┐       │
│  │                   🗣️                            │       │
│  │              Vocabulary                          │       │
│  │  Pelajari kosakata baru dengan gambar           │       │
│  └─────────────────────────────────────────────────┘       │
│                                                              │
│  ┌─────────────────────────────────────────────────┐       │
│  │                   🎧                            │       │
│  │               Listening                          │       │
│  │  Latih kemampuan mendengar Bahasa Inggris       │       │
│  └─────────────────────────────────────────────────┘       │
│                                                              │
│  ┌─────────────────────────────────────────────────┐       │
│  │                   🎮                            │       │
│  │                  Quiz                            │       │
│  │  Uji kemampuanmu dengan soal interaktif         │       │
│  └─────────────────────────────────────────────────┘       │
│                                                              │
└────────────────────────────────────────────────────────────┘
```

---

## 🎮 Skenario Quiz Seperti Duolingo

### 1. Vocabulary Matching (Duolingo Style)
```
┌────────────────────────────────────┐
│ [X]  ━━━━━━━━━━━━━━━━━━━━━  1/10  │
├────────────────────────────────────┤
│                                    │
│  [Vocabulary Matching]             │
│                                    │
│  What color is this?               │
│                                    │
│      ┌────────────────┐            │
│      │                │            │
│      │  [Red Apple]   │            │
│      │    Image       │            │
│      │                │            │
│      └────────────────┘            │
│                                    │
│  ┌──────────────────────────────┐ │
│  │  A. Red          [○]         │ │
│  └──────────────────────────────┘ │
│  ┌──────────────────────────────┐ │
│  │  B. Blue         [○]         │ │
│  └──────────────────────────────┘ │
│  ┌──────────────────────────────┐ │
│  │  C. Green        [○]         │ │
│  └──────────────────────────────┘ │
│  ┌──────────────────────────────┐ │
│  │  D. Yellow       [○]         │ │
│  └──────────────────────────────┘ │
│                                    │
│        [CEK JAWABAN]               │
│                                    │
└────────────────────────────────────┘
```

### 2. After Answer (Correct)
```
┌────────────────────────────────────┐
│ [X]  ━━━━━━━━━━━━━━━━━━━━━  1/10  │
├────────────────────────────────────┤
│                                    │
│  ┌──────────────────────────────┐ │
│  │  ✅ BENAR!                   │ │
│  │                              │ │
│  │  Apel berwarna merah (red)   │ │
│  └──────────────────────────────┘ │
│                                    │
│  ┌──────────────────────────────┐ │
│  │  A. Red          [✓]         │ │
│  └──────────────────────────────┘ │
│  ┌──────────────────────────────┐ │
│  │  B. Blue         [ ]         │ │
│  └──────────────────────────────┘ │
│                                    │
│           [LANJUT →]               │
│                                    │
└────────────────────────────────────┘
```

### 3. Speaking Assessment
```
┌────────────────────────────────────┐
│ [X]  ━━━━━━━━━━━━━━━━━━━━━  5/10  │
├────────────────────────────────────┤
│                                    │
│  [Speaking Assessment]             │
│                                    │
│  Say the word:                     │
│                                    │
│          GREEN                     │
│                                    │
│         ┌──────┐                   │
│         │  🎤  │                   │
│         └──────┘                   │
│    Click to record                 │
│                                    │
│  ┌──────────────────────────────┐ │
│  │  Menunggu rekaman...         │ │
│  └──────────────────────────────┘ │
│                                    │
└────────────────────────────────────┘
```

### 4. Memorizing via Image
```
┌────────────────────────────────────┐
│ [X]  ━━━━━━━━━━━━━━━━━━━━━  8/10  │
├────────────────────────────────────┤
│                                    │
│  [Memorizing via Image]            │
│                                    │
│  What is this fruit in English?    │
│                                    │
│      ┌────────────────┐            │
│      │                │            │
│      │  [Banana]      │            │
│      │    Image       │            │
│      │                │            │
│      └────────────────┘            │
│                                    │
│  ┌──────────────────────────────┐ │
│  │  ____________                │ │
│  │  Type your answer...         │ │
│  └──────────────────────────────┘ │
│                                    │
│        [CEK JAWABAN]               │
│                                    │
└────────────────────────────────────┘
```

---

## 🎯 Summary

Aplikasi FUNLISH telah dibangun dengan fitur lengkap sesuai konsep:

✅ **4 Kelas** (3, 4, 5, 6)
✅ **3 Menu Pembelajaran** (Vocabulary, Listening, Quiz)
✅ **3 Level Quiz** (Level 1, 2, 3)
✅ **5 Tipe Soal** (Vocabulary, Reading, Listening, Speaking, Memorizing)
✅ **Feedback Langsung** saat jawaban salah
✅ **Tanpa Sistem Lock** - semua level terbuka
✅ **Tanpa Ranking** - fokus pada pembelajaran
✅ **Admin Panel** untuk mengelola konten
✅ **Responsive Design** untuk semua device
✅ **Modern UI/UX** dengan animasi smooth

**Aplikasi siap digunakan!** 🚀
