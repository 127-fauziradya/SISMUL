# 🚀 QUICK START - FUNLISH

## Setup dalam 5 Langkah

### 1️⃣ Import Database
```bash
# Buka phpMyAdmin
# Buat database baru: db_funlish
# Import file: db_funlish.sql
# Import data sample: insert_sample_data.sql
```

### 2️⃣ Konfigurasi
File sudah siap pakai dengan konfigurasi default XAMPP:
- Host: localhost
- User: root
- Pass: (kosong)
- DB: db_funlish

### 3️⃣ Jalankan XAMPP
```bash
# Start Apache
# Start MySQL
```

### 4️⃣ Akses Aplikasi
- **Halaman Siswa**: http://localhost/SISMUL_NEW/SISMUL/SISMUL/index.html
- **Admin Panel**: http://localhost/SISMUL_NEW/SISMUL/SISMUL/admin/login.php

### 5️⃣ Login Admin
```
Username: admin
Password: admin123
```

---

## 📂 Struktur File Utama

```
SISMUL/
├── index.html              ← Landing page
├── class-dashboard.html    ← Dashboard setelah pilih kelas
├── vocabulary.html         ← Halaman vocabulary flashcard
├── listening.html          ← Halaman listening audio
├── quiz.html              ← Halaman pilih quiz & level
├── quiz-play.html         ← Halaman main quiz
│
├── api/                   ← Backend API (PHP)
│   ├── get_materi.php
│   ├── get_vocabulary.php
│   ├── get_listening.php
│   ├── get_quiz.php
│   └── get_soal.php
│
├── admin/                 ← Admin panel
│   ├── login.php
│   └── index.php
│
└── config.php            ← Database config
```

---

## ✨ Fitur yang Sudah Jadi

### Untuk Siswa:
- ✅ Pilih kelas (3, 4, 5, 6)
- ✅ Vocabulary dengan flashcard + audio
- ✅ Listening dengan audio player
- ✅ Quiz 3 level dengan 5 tipe soal:
  - Vocabulary Matching
  - Reading Comprehension
  - Listening Comprehension
  - Speaking Assessment (Speech Recognition)
  - Memorizing via Image

### Untuk Admin:
- ✅ Login system
- ✅ Dashboard dengan statistik
- ✅ Manage materi, vocabulary, listening, quiz, soal

---

## 🎯 Testing Checklist

### Test Siswa:
1. [ ] Buka landing page
2. [ ] Klik "Masuk Kelas" untuk kelas 3
3. [ ] Klik menu "Vocabulary"
4. [ ] Flip flashcard, dengar audio
5. [ ] Kembali, klik "Listening"
6. [ ] Play audio, lihat transkrip
7. [ ] Kembali, klik "Quiz"
8. [ ] Pilih Level 1
9. [ ] Klik quiz yang tersedia
10. [ ] Kerjakan semua tipe soal

### Test Admin:
1. [ ] Login ke admin panel
2. [ ] Lihat dashboard & statistik
3. [ ] Coba tambah materi baru
4. [ ] Coba tambah vocabulary
5. [ ] Coba tambah quiz & soal

---

## 🐛 Common Issues & Fix

### Database connection error:
```php
// Cek config.php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_funlish');
```

### API tidak return data:
- Cek apakah database sudah diimport
- Cek apakah ada data di tabel
- Buka browser console untuk lihat error

### Audio tidak keluar:
- Cek browser support (Chrome recommended)
- Izinkan akses audio di browser
- Cek file audio sudah diupload

### Speech Recognition tidak work:
- Gunakan Chrome/Edge (Firefox tidak support)
- Izinkan akses microphone
- Butuh koneksi internet

---

## 📱 Browser Support

| Browser | Vocabulary | Listening | Quiz | Speaking |
|---------|-----------|-----------|------|----------|
| Chrome  | ✅         | ✅         | ✅    | ✅        |
| Edge    | ✅         | ✅         | ✅    | ✅        |
| Firefox | ✅         | ✅         | ✅    | ❌        |
| Safari  | ✅         | ✅         | ✅    | ⚠️        |

**Rekomendasi: Google Chrome**

---

## 🎨 Customization Tips

### Ganti Warna Tema:
Edit `style.css`:
```css
/* Primary Color */
#58cc02 → Your color

/* Background */
#f7fff5 → Your color
```

### Ganti Font:
Edit `index.html` (dan semua HTML):
```html
<link href="https://fonts.googleapis.com/css2?family=YourFont" rel="stylesheet">
```

### Tambah Kelas Baru:
```sql
INSERT INTO kelas (id_kelas, nama_kelas) VALUES (7, 'Kelas 7');
```

---

## 📚 Dokumentasi Lengkap

Baca file berikut untuk detail lengkap:
- `README_FITUR.md` - Penjelasan fitur lengkap
- `DOKUMENTASI_LENGKAP.md` - Konsep, alur, wireframe
- `konsep.md` - Konsep awal aplikasi

---

## 🆘 Butuh Bantuan?

1. Cek dokumentasi lengkap di file README
2. Cek browser console untuk error
3. Cek phpMyAdmin untuk data
4. Cek Apache error log

---

**Happy Coding! 🚀**
